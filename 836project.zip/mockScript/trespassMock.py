import time, requests
def trespassing_mock():
    time.sleep(2)
    r = requests.get('http://localhost:1880/trespassing')

trespassing_mock()