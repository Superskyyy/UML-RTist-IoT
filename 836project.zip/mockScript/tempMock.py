import os
import time
import random
import requests

token = ['jk1Iperz264sdOjHBoCs', '3QofnzegyhWEKDr8Q81X', '9dJsCzVqmIMSP0ez1bTz', 'V7yk0C6jxJbfTxiJeMIA',
         'JIlNRqKY32W1POwMmX7m']


def temp_mock():
    is_fire_putout = False
    random_fire_pos = random.randint(0, 4)
    temperature_propagated = [20, 20, 20, 20, 20]

    while True:
        time.sleep(7)  # mock a temp update every 7 seconds

        if not is_fire_putout:
            print(random_fire_pos)
            temperature_propagated[random_fire_pos] += random.randint(25, 50)
            for idx in range(len(temperature_propagated)):
                #random_temp_increase = random.randint(0, 4)
                #random_temp_increase = random_temp_increase if random_temp_increase != random_fire_pos else 0
                #temperature_propagated[random_temp_increase] += random.randint(0, 13)
                temperature_propagated[idx] += random.randint(0, 15)

        for i in range(5):
            os.popen('curl -v -X POST -d "{\"temperature\": %d}"'
                     ' https://thingsboard.cloud/api/v1/%s/telemetry '
                     '--header "Content-Type:application/json"' % (temperature_propagated[i], token[i]))
            if temperature_propagated[i] > 80:
                os.popen('curl -v -X POST -d "{\"triggered\": %s}"'
                         ' https://thingsboard.cloud/api/v1/%s/telemetry '
                         '--header "Content-Type:application/json"' % ('true', token[i]))
        # print(res)
        # os.environ['NO_PROXY'] = '127.0.0.1'
        print(type(random_fire_pos))
        r = requests.post('http://localhost:1880/temp',
                          data={"data": str(temperature_propagated[random_fire_pos]) + "w"})
        print(r.content)

        if temperature_propagated[random_fire_pos] > 200 or is_fire_putout:
            temperature_propagated[random_fire_pos] -= random.randint(-15, 80)
            if temperature_propagated[random_fire_pos] <= 25:
                temperature_propagated[random_fire_pos] = 25

            is_fire_putout = True
        if is_fire_putout:
            for idx in range(len(temperature_propagated)):
                if not temperature_propagated[idx] < 35:
                    temperature_propagated[idx] -= random.randint(5, 20)
        end = True
        for temp in temperature_propagated:
            if temp > 35:
                end = False
        if end:
            for i in range(5):
                os.popen('curl -v -X POST -d "{\"triggered\": %s}"'
                         ' https://thingsboard.cloud/api/v1/%s/telemetry '
                         '--header "Content-Type:application/json"' % ('false', token[i]))
            os.popen('curl -v -X POST -d "{\"enabled\": %s}"'
                     ' https://thingsboard.cloud/api/v1/b8lEDVIoxhMKrAJ8GP8f/telemetry '
                     '--header "Content-Type:application/json"' % 'false')
            quit()


temp_mock()
