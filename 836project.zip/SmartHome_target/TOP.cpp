/* ;rt-indent: 0;rt-indent-char-sp; */
#if defined( PRAGMA ) && ! defined( PRAGMA_IMPLEMENTED )
#pragma implementation "TOP.h"
#endif
#include <UnitName.h>
#include <TOP.h>
#include <AlarmControl.h>

extern const RTActorClass MyTCPServer;

extern const RTActorClass SmartHome;

static const char * const rtg_state_names[] =
{
    "<machine>"
    , "State1"
};

static const RTInterfaceDescriptor rtg_interfaces_smartHome[] =
{
    {
        "alarm"
        , 1
    }
};

static const RTBindingDescriptor rtg_bindings_smartHome[] =
{
    {
        0
        , &AlarmControl::Conjugate::rt_class
    }
};

static const RTInterfaceDescriptor rtg_interfaces_server[] =
{
    {
        nullptr
        , 0
    }
    , {
        "alarmControl"
        , 1
    }
};

static const RTBindingDescriptor rtg_bindings_server[] =
{
    {
        1
        , &AlarmControl::Base::rt_class
    }
};

#define SUPER RTActor
TOP_Actor::TOP_Actor( RTController * rtg_rts, RTActorRef * rtg_ref )
    : RTActor( rtg_rts ,rtg_ref )
{
}

TOP_Actor::~TOP_Actor( void )
{
}

INLINE_CHAINS void TOP_Actor::chain1_Initial( void )
{
    rtgChainBegin( 1, "Initial" );
    rtgTransitionBegin(  );
    rtgTransitionEnd(  );
    enterState( 2 );
}

void TOP_Actor::rtsBehavior( int signalIndex, int portIndex )
{
    for (int stateIndex = getCurrentState() ; ;stateIndex = rtg_parent_state[ stateIndex - 1 ] )
        {
            switch( stateIndex )
            {
            case 1:
                switch( portIndex )
                {
                case 0:
                    switch( signalIndex )
                    {
                    case 1 /*RTInitSignal*/:
                        chain1_Initial(  );
                        return ;
                    default:
                        break;
                    }
                    break;
                default:
                    break;
                }
                unexpectedMessage(  );
                return ;
            case 2 /* State1 (State Machine::State1) */:
                switch( portIndex )
                {
                case 0 /*RTControlPort*/:
                    switch( signalIndex )
                    {
                    case 1 /*RTInitSignal*/:
                        return ;
                    default:
                        break;
                    }
                    break;
                default:
                    break;
                }
                break;
            default:
                unexpectedState(  );
                return ;
            }
        }
}

const RTStateId TOP_Actor::rtg_parent_state[] =
{
    0
    , 1
};

const RTActor_class * TOP_Actor::getActorData( void ) const
{
    return &TOP_Actor::rtg_class;
}

const RTActor_class TOP_Actor::rtg_class =
{
    nullptr
    , rtg_state_names
    , 2
    , TOP_Actor::rtg_parent_state
    , &TOP
    , 2
    , TOP_Actor::rtg_capsule_roles
    , 0
    , nullptr
    , 0
    , nullptr
    , 0
    , nullptr
};

const RTComponentDescriptor TOP_Actor::rtg_capsule_roles[] =
{
    {
        "smartHome"
        , &SmartHome
        , RTOffsetOf( TOP_Actor, smartHome )
        , 1
        , RTComponentDescriptor::Fixed
        , 1
        , 1
        , 1
        , rtg_interfaces_smartHome
        , 1
        , rtg_bindings_smartHome
    }
    , {
        "server"
        , &MyTCPServer
        , RTOffsetOf( TOP_Actor, server )
        , 2
        , RTComponentDescriptor::Fixed
        , 1
        , 1
        , 2
        , rtg_interfaces_server
        , 1
        , rtg_bindings_server
    }
};

int TOP_Actor::_followOutV( RTBindingEnd & rtg_end, int rtg_compId, int rtg_portId, int rtg_repIndex )
{
    switch( rtg_compId )
    {
    case 1:
        switch( rtg_portId )
        {
        case 0:
            if( rtg_repIndex < 1 )
                return server._followIn( rtg_end, 1, rtg_repIndex );
            break;
        default:
            break;
        }
        break;
    case 2:
        switch( rtg_portId )
        {
        case 1:
            if( rtg_repIndex < 1 )
                return smartHome._followIn( rtg_end, 0, rtg_repIndex );
            break;
        default:
            break;
        }
        break;
    default:
        break;
    }
    return RTActor::_followOutV( rtg_end, rtg_compId, rtg_portId, rtg_repIndex );
}

#undef SUPER
static RTActor * new_TOP_Actor( RTController * rtg_rts, RTActorRef * rtg_ref )
{
    return new TOP_Actor( rtg_rts, rtg_ref );
}

const RTActorClass TOP =
{
    nullptr
    , "TOP"
    , 0 /*RTVersionId*/
    , 0
    , nullptr
    , new_TOP_Actor
};

