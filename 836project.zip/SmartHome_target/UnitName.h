/* ;rt-indent: 0;rt-indent-char-sp; */
#ifndef UnitName_h
#define UnitName_h

#ifdef PRAGMA
#pragma interface "UnitName.h"
#endif
#ifndef ATTR_UNUSED
#ifdef __GNUC__
#define ATTR_UNUSED __attribute__((unused))
#else 
#define ATTR_UNUSED
#endif
#endif
#include <RTStructures.h>
#endif /* UnitName_h */
