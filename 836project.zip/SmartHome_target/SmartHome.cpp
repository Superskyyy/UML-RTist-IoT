/* ;rt-indent: 0;rt-indent-char-sp; */
#if defined( PRAGMA ) && ! defined( PRAGMA_IMPLEMENTED )
#pragma implementation "SmartHome.h"
#endif
#include <UnitName.h>
#include <SmartHome.h>

static const char * const rtg_state_names[] =
{
    "<machine>"
    , "State1"
    , "Normal"
    , "Fire_Alarm"
    , "SOS_Alarm"
    , "Trespass_Alarm"
};

#define SUPER RTActor
SmartHome_Actor::SmartHome_Actor( RTController * rtg_rts, RTActorRef * rtg_ref )
    : RTActor( rtg_rts ,rtg_ref )
{
}

SmartHome_Actor::~SmartHome_Actor( void )
{
}

INLINE_METHODS void SmartHome_Actor::enter3_Normal( void )
{
//{{{USR platform:/resource/SmartHomeIoT/TrafficLightComponent.emx#_E2SwsJ2mEeuzL4RfgatO1w
log.log("This is normal state");

//}}}USR
}

void SmartHome_Actor::enterStateV( void )
{
    switch( getCurrentState() )
    {
    case 3:
        enter3_Normal(  );
        break;
    case 4:
        enter4_Fire_Alarm(  );
        break;
    case 5:
        enter5_SOS_Alarm(  );
        break;
    case 6:
        enter6_Trespass_Alarm(  );
        break;
    default:
        RTActor::enterStateV(  );
        break;
    }
}

INLINE_METHODS void SmartHome_Actor::enter4_Fire_Alarm( void )
{
//{{{USR platform:/resource/SmartHomeIoT/TrafficLightComponent.emx#_tU7isJ2mEeuzL4RfgatO1w
//RTMessage sendEvent;
//log.log(sendEvent.getData());
//int temperature = *((int*) sendEvent.getData());
//log.log(sendEvent.getPriority()); // all 0 meaning message is not received here!! -sky
log.log("Fire event detected, sending alarm to Dashboard");
//log.log(sendEvent.getData());
//log.log("here");
timer.informIn(RTTimespec(1, 0));

alarm.fireTriggered(RTString("fire")).send();
//}}}USR
}

INLINE_METHODS void SmartHome_Actor::enter5_SOS_Alarm( void )
{
//{{{USR platform:/resource/SmartHomeIoT/TrafficLightComponent.emx#__iYtcJ2tEeuzL4RfgatO1w
log.log("SoS");
timer.informIn(RTTimespec(1, 0));
alarm.sosTriggered(RTString("sos")).send();
//}}}USR
}

INLINE_METHODS void SmartHome_Actor::enter6_Trespass_Alarm( void )
{
//{{{USR platform:/resource/SmartHomeIoT/TrafficLightComponent.emx#_AxkR0J24EeuzL4RfgatO1w
log.log("Trespass");
timer.informIn(RTTimespec(1, 0));
alarm.trespassingTriggered(RTString("trespass")).send();
//}}}USR
}

INLINE_METHODS void SmartHome_Actor::transition1_Initial( const void * rtdata, RTProtocol * rtport )
{
//{{{USR platform:/resource/SmartHomeIoT/TrafficLightComponent.emx#_piCwE8j6EemAJ4GeYf92vQ
log.log("TrafficLight starts up");
//}}}USR
}

INLINE_METHODS void SmartHome_Actor::transition3_fire_alarm( const void * rtdata, AlarmControl::Base * rtport )
{
//{{{USR platform:/resource/SmartHomeIoT/TrafficLightComponent.emx#_pYEC4J4GEeu7t6RIZIZzEQ
//RTMessage sendEvent;
//RTString data;

//int temperature = *((int*) sendEvent.getData());
//log.log('gere');

//}}}USR
}

INLINE_CHAINS void SmartHome_Actor::chain1_Initial_2( void )
{
    rtgChainBegin( 1, "Initial" );
    rtgTransitionBegin(  );
    transition1_Initial( msg->data, msg->sap() );
    rtgTransitionEnd(  );
    enterState( 2 );
    rtgChainBegin( 2, "Initial" );
    rtgTransitionBegin(  );
    rtgTransitionEnd(  );
    enterState( 3 );
}

INLINE_CHAINS void SmartHome_Actor::chain3_fire_alarm( void )
{
    rtgChainBegin( 3, "fire_alarm" );
    exitState( rtg_parent_state );
    rtgTransitionBegin(  );
    transition3_fire_alarm( msg->data, static_cast< AlarmControl::Base * > ( msg->sap() ) );
    rtgTransitionEnd(  );
    enterState( 4 );
}

INLINE_CHAINS void SmartHome_Actor::chain4_sos_alarm( void )
{
    rtgChainBegin( 3, "sos_alarm" );
    exitState( rtg_parent_state );
    rtgTransitionBegin(  );
    rtgTransitionEnd(  );
    enterState( 5 );
}

INLINE_CHAINS void SmartHome_Actor::chain5_back( void )
{
    rtgChainBegin( 4, "back" );
    exitState( rtg_parent_state );
    rtgTransitionBegin(  );
    rtgTransitionEnd(  );
    enterState( 3 );
}

INLINE_CHAINS void SmartHome_Actor::chain6_back( void )
{
    rtgChainBegin( 5, "back" );
    exitState( rtg_parent_state );
    rtgTransitionBegin(  );
    rtgTransitionEnd(  );
    enterState( 3 );
}

INLINE_CHAINS void SmartHome_Actor::chain7_trespass_alarm( void )
{
    rtgChainBegin( 3, "trespass_alarm" );
    exitState( rtg_parent_state );
    rtgTransitionBegin(  );
    rtgTransitionEnd(  );
    enterState( 6 );
}

INLINE_CHAINS void SmartHome_Actor::chain8_back( void )
{
    rtgChainBegin( 6, "back" );
    exitState( rtg_parent_state );
    rtgTransitionBegin(  );
    rtgTransitionEnd(  );
    enterState( 3 );
}

void SmartHome_Actor::rtsBehavior( int signalIndex, int portIndex )
{
    for (int stateIndex = getCurrentState() ; ;stateIndex = rtg_parent_state[ stateIndex - 1 ] )
        {
            switch( stateIndex )
            {
            case 1:
                switch( portIndex )
                {
                case 0:
                    switch( signalIndex )
                    {
                    case 1 /*RTInitSignal*/:
                        chain1_Initial_2(  );
                        return ;
                    default:
                        break;
                    }
                    break;
                default:
                    break;
                }
                unexpectedMessage(  );
                return ;
            case 2 /* State1 (State Machine::State1) */:
                switch( portIndex )
                {
                case 0 /*RTControlPort*/:
                    switch( signalIndex )
                    {
                    case 1 /*RTInitSignal*/:
                        return ;
                    default:
                        break;
                    }
                    break;
                default:
                    break;
                }
                break;
            case 3 /* Normal (State Machine::State1::Normal) */:
                switch( portIndex )
                {
                case 0 /*RTControlPort*/:
                    switch( signalIndex )
                    {
                    case 1 /*RTInitSignal*/:
                        return ;
                    default:
                        break;
                    }
                    break;
                case 3 /*alarm*/:
                    switch( signalIndex )
                    {
                    case AlarmControl::Base::rti_fire:
                        chain3_fire_alarm(  );
                        return ;
                    case AlarmControl::Base::rti_sos:
                        chain4_sos_alarm(  );
                        return ;
                    case AlarmControl::Base::rti_trespassing:
                        chain7_trespass_alarm(  );
                        return ;
                    default:
                        break;
                    }
                    break;
                default:
                    break;
                }
                break;
            case 4 /* Fire_Alarm (State Machine::State1::Fire_Alarm) */:
                switch( portIndex )
                {
                case 0 /*RTControlPort*/:
                    switch( signalIndex )
                    {
                    case 1 /*RTInitSignal*/:
                        return ;
                    default:
                        break;
                    }
                    break;
                case 2 /*timer*/:
                    chain5_back(  );
                    return ;
                default:
                    break;
                }
                break;
            case 5 /* SOS_Alarm (State Machine::State1::SOS_Alarm) */:
                switch( portIndex )
                {
                case 0 /*RTControlPort*/:
                    switch( signalIndex )
                    {
                    case 1 /*RTInitSignal*/:
                        return ;
                    default:
                        break;
                    }
                    break;
                case 2 /*timer*/:
                    chain6_back(  );
                    return ;
                default:
                    break;
                }
                break;
            case 6 /* Trespass_Alarm (State Machine::State1::Trespass_Alarm) */:
                switch( portIndex )
                {
                case 0 /*RTControlPort*/:
                    switch( signalIndex )
                    {
                    case 1 /*RTInitSignal*/:
                        return ;
                    default:
                        break;
                    }
                    break;
                case 2 /*timer*/:
                    chain8_back(  );
                    return ;
                default:
                    break;
                }
                break;
            default:
                unexpectedState(  );
                return ;
            }
        }
}

const RTStateId SmartHome_Actor::rtg_parent_state[] =
{
    0
    , 1
    , 2
    , 2
    , 2
    , 2
};

const RTActor_class * SmartHome_Actor::getActorData( void ) const
{
    return &SmartHome_Actor::rtg_class;
}

const RTActor_class SmartHome_Actor::rtg_class =
{
    nullptr
    , rtg_state_names
    , 6
    , SmartHome_Actor::rtg_parent_state
    , &SmartHome
    , 0
    , nullptr
    , 3
    , SmartHome_Actor::rtg_ports
    , 0
    , nullptr
    , 0
    , nullptr
};

const RTPortDescriptor SmartHome_Actor::rtg_ports[] =
{
    {
        "alarm"
        , nullptr
        , &AlarmControl::Base::rt_class
        , RTOffsetOf( SmartHome_Actor, alarm )
        , 1
        , 3
        , RTPortDescriptor::KindWired + RTPortDescriptor::NotificationDisabled + RTPortDescriptor::RegisterNotPermitted + RTPortDescriptor::VisibilityPublic
    }
    , {
        "log"
        , nullptr
        , &Log::Base::rt_class
        , RTOffsetOf( SmartHome_Actor, log )
        , 1
        , 1
        , RTPortDescriptor::KindSpecial + RTPortDescriptor::NotificationDisabled + RTPortDescriptor::RegisterNotPermitted + RTPortDescriptor::VisibilityPublic
    }
    , {
        "timer"
        , nullptr
        , &Timing::Base::rt_class
        , RTOffsetOf( SmartHome_Actor, timer )
        , 1
        , 2
        , RTPortDescriptor::KindSpecial + RTPortDescriptor::NotificationDisabled + RTPortDescriptor::RegisterNotPermitted + RTPortDescriptor::VisibilityPublic
    }
};

int SmartHome_Actor::_followInV( RTBindingEnd & rtg_end, int rtg_portId, int rtg_repIndex )
{
    switch( rtg_portId )
    {
    case 0:
        if( rtg_repIndex < 1 )
        {
            rtg_end.port = &alarm;
            rtg_end.index = rtg_repIndex;
            return 1;
        }
        break;
    default:
        break;
    }
    return RTActor::_followInV( rtg_end, rtg_portId, rtg_repIndex );
}

#undef SUPER
static const RTRelayDescriptor rtg_relays[] =
{
    {
        "alarm"
        , &AlarmControl::Base::rt_class
        , 1
    }
};

static RTActor * new_SmartHome_Actor( RTController * rtg_rts, RTActorRef * rtg_ref )
{
    return new SmartHome_Actor( rtg_rts, rtg_ref );
}

const RTActorClass SmartHome =
{
    nullptr
    , "SmartHome"
    , 0 /*RTVersionId*/
    , 1
    , rtg_relays
    , new_SmartHome_Actor
};

