/* ;rt-indent: 0;rt-indent-char-sp; */
#ifndef MyTCPServer_h
#define MyTCPServer_h

#ifdef PRAGMA
#pragma interface "MyTCPServer.h"
#endif
#include <UnitName.h>
#include <AlarmControl.h>
#include <TCPServer.h>
#define SUPER TCPServer_Actor
class MyTCPServer_Actor : public TCPServer_Actor
{
public:
    MyTCPServer_Actor( RTController * rtg_rts, RTActorRef * rtg_ref );
    virtual ~MyTCPServer_Actor( void );
protected:
    AlarmControl::Conjugate alarmControl;
public:
    virtual void init( void ) override;
private:
    INLINE_CHAINS void chain1_Initial( void );
    INLINE_CHAINS void chain2_requestReceived( void );
    INLINE_CHAINS void chain3_stop( void );
public:
    virtual void rtsBehavior( int signalIndex, int portIndex ) override;
    static const RTStateId rtg_parent_state[];
    virtual const RTActor_class * getActorData( void ) const override;
protected:
    static const RTActor_class rtg_class;
private:
    static const RTPortDescriptor rtg_ports[];
public:
    virtual int _followInV( RTBindingEnd & rtg_end, int rtg_portId, int rtg_repIndex ) override;
};
#undef SUPER
extern const RTActorClass MyTCPServer;
#endif /* MyTCPServer_h */
