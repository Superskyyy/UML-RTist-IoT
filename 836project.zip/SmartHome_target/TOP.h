/* ;rt-indent: 0;rt-indent-char-sp; */
#ifndef TOP_h
#define TOP_h

#ifdef PRAGMA
#pragma interface "TOP.h"
#endif
#include <UnitName.h>
#define SUPER RTActor
class TOP_Actor : public RTActor
{
public:
    TOP_Actor( RTController * rtg_rts, RTActorRef * rtg_ref );
    virtual ~TOP_Actor( void );
protected:
    RTActorRef smartHome;
    RTActorRef server;
private:
    INLINE_CHAINS void chain1_Initial( void );
public:
    virtual void rtsBehavior( int signalIndex, int portIndex ) override;
    static const RTStateId rtg_parent_state[];
    virtual const RTActor_class * getActorData( void ) const override;
protected:
    static const RTActor_class rtg_class;
private:
    static const RTComponentDescriptor rtg_capsule_roles[];
public:
    virtual int _followOutV( RTBindingEnd & rtg_end, int rtg_compId, int rtg_portId, int rtg_repIndex ) override;
};
#undef SUPER
extern const RTActorClass TOP;
#endif /* TOP_h */
