/* ;rt-indent: 0;rt-indent-char-sp; */
#if defined( PRAGMA ) && ! defined( PRAGMA_IMPLEMENTED )
#pragma implementation "AlarmControl.h"
#endif
#include <UnitName.h>
#include <AlarmControl.h>

const RTProtocolDescriptor AlarmControl::Base::rt_class =
{
    &RTRootProtocol::rt_class
    , &AlarmControl::Conjugate::rt_class
    , "AlarmControl"
    , 0
    , 5
    , AlarmControl::Base::rt_signals
};

const RTSignalDescriptor AlarmControl::Base::rt_signals[] =
{
    {
        "fire"
        , &RTType_void
        , AlarmControl::Base::rti_fire
    }
    , {
        "rtBound"
        , nullptr
        , AlarmControl::Base::rti_rtBound
    }
    , {
        "rtUnbound"
        , nullptr
        , AlarmControl::Base::rti_rtUnbound
    }
    , {
        "sos"
        , &RTType_void
        , AlarmControl::Base::rti_sos
    }
    , {
        "trespassing"
        , &RTType_void
        , AlarmControl::Base::rti_trespassing
    }
};

const RTProtocolDescriptor AlarmControl::Conjugate::rt_class =
{
    &RTRootProtocol::rt_class
    , &AlarmControl::Base::rt_class
    , "AlarmControl"
    , 0
    , 5
    , AlarmControl::Conjugate::rt_signals
};

const RTSignalDescriptor AlarmControl::Conjugate::rt_signals[] =
{
    {
        "fireTriggered"
        , &RTType_RTString
        , AlarmControl::Conjugate::rti_fireTriggered
    }
    , {
        "rtBound"
        , nullptr
        , AlarmControl::Conjugate::rti_rtBound
    }
    , {
        "rtUnbound"
        , nullptr
        , AlarmControl::Conjugate::rti_rtUnbound
    }
    , {
        "sosTriggered"
        , &RTType_RTString
        , AlarmControl::Conjugate::rti_sosTriggered
    }
    , {
        "trespassingTriggered"
        , &RTType_RTString
        , AlarmControl::Conjugate::rti_trespassingTriggered
    }
};

