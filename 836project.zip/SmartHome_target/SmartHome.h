/* ;rt-indent: 0;rt-indent-char-sp; */
#ifndef SmartHome_h
#define SmartHome_h

#ifdef PRAGMA
#pragma interface "SmartHome.h"
#endif
#include <UnitName.h>
#include <AlarmControl.h>
#define SUPER RTActor
class SmartHome_Actor : public RTActor
{
public:
    SmartHome_Actor( RTController * rtg_rts, RTActorRef * rtg_ref );
    virtual ~SmartHome_Actor( void );
protected:
    Log::Base log;
    Timing::Base timer;
    AlarmControl::Base alarm;
    INLINE_METHODS void enter3_Normal( void );
    virtual void enterStateV( void ) override;
    INLINE_METHODS void enter4_Fire_Alarm( void );
    INLINE_METHODS void enter5_SOS_Alarm( void );
    INLINE_METHODS void enter6_Trespass_Alarm( void );
    INLINE_METHODS void transition1_Initial( const void * rtdata, RTProtocol * rtport );
    INLINE_METHODS void transition3_fire_alarm( const void * rtdata, AlarmControl::Base * rtport );
private:
    INLINE_CHAINS void chain1_Initial_2( void );
    INLINE_CHAINS void chain3_fire_alarm( void );
    INLINE_CHAINS void chain4_sos_alarm( void );
    INLINE_CHAINS void chain5_back( void );
    INLINE_CHAINS void chain6_back( void );
    INLINE_CHAINS void chain7_trespass_alarm( void );
    INLINE_CHAINS void chain8_back( void );
public:
    virtual void rtsBehavior( int signalIndex, int portIndex ) override;
    static const RTStateId rtg_parent_state[];
    virtual const RTActor_class * getActorData( void ) const override;
protected:
    static const RTActor_class rtg_class;
private:
    static const RTPortDescriptor rtg_ports[];
public:
    virtual int _followInV( RTBindingEnd & rtg_end, int rtg_portId, int rtg_repIndex ) override;
};
#undef SUPER
extern const RTActorClass SmartHome;
#endif /* SmartHome_h */
