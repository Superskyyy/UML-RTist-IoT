/* ;rt-indent: 0;rt-indent-char-sp; */
#ifndef AlarmControl_h
#define AlarmControl_h

#ifdef PRAGMA
#pragma interface "AlarmControl.h"
#endif
#include <UnitName.h>
struct AlarmControl
{
    class Base : public RTRootProtocol
    {
    public:
        inline Base( void );
        inline ~Base( void );
        enum
        {
            rti_fire = rtiLast_RTRootProtocol + 1
            , rti_sos
            , rti_trespassing
        };
    protected:
        enum
        {
            rtiLast_AlarmControl = rti_trespassing
        };
    public:
        inline RTInSignal fire( void );
        inline RTInSignal sos( void );
        inline RTInSignal trespassing( void );
        inline RTOutSignal fireTriggered( const RTTypedValue_RTString & data );
        inline RTOutSignal sosTriggered( const RTTypedValue_RTString & data );
        inline RTOutSignal trespassingTriggered( const RTTypedValue_RTString & data );
        static const RTProtocolDescriptor rt_class;
    private:
        static const RTSignalDescriptor rt_signals[];
    };
    class Conjugate : public RTRootProtocol
    {
    public:
        inline Conjugate( void );
        inline ~Conjugate( void );
        enum
        {
            rti_fireTriggered = rtiLast_RTRootProtocol + 1
            , rti_sosTriggered
            , rti_trespassingTriggered
        };
    protected:
        enum
        {
            rtiLast_AlarmControl = rti_trespassingTriggered
        };
    public:
        inline RTInSignal fireTriggered( void );
        inline RTInSignal sosTriggered( void );
        inline RTInSignal trespassingTriggered( void );
        inline RTOutSignal fire( void );
        inline RTOutSignal sos( void );
        inline RTOutSignal trespassing( void );
        static const RTProtocolDescriptor rt_class;
    private:
        static const RTSignalDescriptor rt_signals[];
    };
};
inline AlarmControl::Base::Base( void )
    : RTRootProtocol(  )
{
}

inline AlarmControl::Base::~Base( void )
{
}

inline RTInSignal AlarmControl::Base::fire( void )
{
    return RTInSignal( this, rti_fire );
}

inline RTInSignal AlarmControl::Base::sos( void )
{
    return RTInSignal( this, rti_sos );
}

inline RTInSignal AlarmControl::Base::trespassing( void )
{
    return RTInSignal( this, rti_trespassing );
}

inline RTOutSignal AlarmControl::Base::fireTriggered( const RTTypedValue_RTString & data )
{
    return RTOutSignal( this, Conjugate::rti_fireTriggered, data.data, data.type );
}

inline RTOutSignal AlarmControl::Base::sosTriggered( const RTTypedValue_RTString & data )
{
    return RTOutSignal( this, Conjugate::rti_sosTriggered, data.data, data.type );
}

inline RTOutSignal AlarmControl::Base::trespassingTriggered( const RTTypedValue_RTString & data )
{
    return RTOutSignal( this, Conjugate::rti_trespassingTriggered, data.data, data.type );
}

inline AlarmControl::Conjugate::Conjugate( void )
    : RTRootProtocol(  )
{
}

inline AlarmControl::Conjugate::~Conjugate( void )
{
}

inline RTInSignal AlarmControl::Conjugate::fireTriggered( void )
{
    return RTInSignal( this, rti_fireTriggered );
}

inline RTInSignal AlarmControl::Conjugate::sosTriggered( void )
{
    return RTInSignal( this, rti_sosTriggered );
}

inline RTInSignal AlarmControl::Conjugate::trespassingTriggered( void )
{
    return RTInSignal( this, rti_trespassingTriggered );
}

inline RTOutSignal AlarmControl::Conjugate::fire( void )
{
    return RTOutSignal( this, Base::rti_fire, nullptr, &RTType_void );
}

inline RTOutSignal AlarmControl::Conjugate::sos( void )
{
    return RTOutSignal( this, Base::rti_sos, nullptr, &RTType_void );
}

inline RTOutSignal AlarmControl::Conjugate::trespassing( void )
{
    return RTOutSignal( this, Base::rti_trespassing, nullptr, &RTType_void );
}

#endif /* AlarmControl_h */
