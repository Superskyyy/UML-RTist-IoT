/* ;rt-indent: 0;rt-indent-char-sp; */
#if defined( PRAGMA ) && ! defined( PRAGMA_IMPLEMENTED )
#pragma implementation "MyTCPServer.h"
#endif
#include <UnitName.h>
#include <MyTCPServer.h>
#include <TCPServerControl.h>

static const char * const rtg_state_names[] =
{
    "<machine>"
    , "WaitForRequest"
    , "Stopped"
};

#define SUPER TCPServer_Actor
MyTCPServer_Actor::MyTCPServer_Actor( RTController * rtg_rts, RTActorRef * rtg_ref )
    : TCPServer_Actor( rtg_rts ,rtg_ref )
{
}

MyTCPServer_Actor::~MyTCPServer_Actor( void )
{
}

void MyTCPServer_Actor::init( void )
{
//{{{USR platform:/resource/SmartHomeIoT/TrafficLightComponent.emx#_kyS0wM7wEemmN6_tu-6YvA
config.remotePort = 9922;
//}}}USR
}

INLINE_CHAINS void MyTCPServer_Actor::chain1_Initial( void )
{
    rtgChainBegin( 1, "Initial" );
    rtgTransitionBegin(  );
    transition1_Initial( msg->data, msg->sap() );
    rtgTransitionEnd(  );
    enterState( 2 );
}

INLINE_CHAINS void MyTCPServer_Actor::chain2_requestReceived( void )
{
    rtgChainBegin( 2, "requestReceived" );
    exitState( rtg_parent_state );
    rtgTransitionBegin(  );
    transition2_requestReceived( msg->data, static_cast< External::Base * > ( msg->sap() ) );
    rtgTransitionEnd(  );
    enterState( 2 );
}

INLINE_CHAINS void MyTCPServer_Actor::chain3_stop( void )
{
    rtgChainBegin( 2, "stop" );
    exitState( rtg_parent_state );
    rtgTransitionBegin(  );
    rtgTransitionEnd(  );
    enterState( 3 );
}

void MyTCPServer_Actor::rtsBehavior( int signalIndex, int portIndex )
{
    for (int stateIndex = getCurrentState() ; ;stateIndex = rtg_parent_state[ stateIndex - 1 ] )
        {
            switch( stateIndex )
            {
            case 1:
                switch( portIndex )
                {
                case 0:
                    switch( signalIndex )
                    {
                    case 1 /*RTInitSignal*/:
                        chain1_Initial(  );
                        return ;
                    default:
                        break;
                    }
                    break;
                default:
                    break;
                }
                unexpectedMessage(  );
                return ;
            case 2 /* WaitForRequest (State Machine::WaitForRequest) */:
                switch( portIndex )
                {
                case 0 /*RTControlPort*/:
                    switch( signalIndex )
                    {
                    case 1 /*RTInitSignal*/:
                        return ;
                    default:
                        break;
                    }
                    break;
                case 1 /*external*/:
                    switch( signalIndex )
                    {
                    case External::Base::rti_event:
                        chain2_requestReceived(  );
                        return ;
                    default:
                        break;
                    }
                    break;
                case 2 /*control*/:
                    switch( signalIndex )
                    {
                    case TCPServerControl::Base::rti_stop:
                        chain3_stop(  );
                        return ;
                    default:
                        break;
                    }
                    break;
                default:
                    break;
                }
                break;
            case 3 /* Stopped (State Machine::Stopped) */:
                switch( portIndex )
                {
                case 0 /*RTControlPort*/:
                    switch( signalIndex )
                    {
                    case 1 /*RTInitSignal*/:
                        return ;
                    default:
                        break;
                    }
                    break;
                default:
                    break;
                }
                break;
            default:
                unexpectedState(  );
                return ;
            }
        }
}

const RTStateId MyTCPServer_Actor::rtg_parent_state[] =
{
    0
    , 1
    , 1
};

const RTActor_class * MyTCPServer_Actor::getActorData( void ) const
{
    return &MyTCPServer_Actor::rtg_class;
}

const RTActor_class MyTCPServer_Actor::rtg_class =
{
    &TCPServer_Actor::rtg_class
    , rtg_state_names
    , 3
    , MyTCPServer_Actor::rtg_parent_state
    , &MyTCPServer
    , 0
    , nullptr
    , 3
    , MyTCPServer_Actor::rtg_ports
    , 0
    , nullptr
    , 0
    , nullptr
};

const RTPortDescriptor MyTCPServer_Actor::rtg_ports[] =
{
    {
        "control"
        , nullptr
        , &TCPServerControl::Base::rt_class
        , RTOffsetOf( MyTCPServer_Actor, control )
        , 1
        , 2
        , RTPortDescriptor::KindWired + RTPortDescriptor::NotificationDisabled + RTPortDescriptor::RegisterNotPermitted + RTPortDescriptor::VisibilityPublic
    }
    , {
        "alarmControl"
        , nullptr
        , &AlarmControl::Conjugate::rt_class
        , RTOffsetOf( MyTCPServer_Actor, alarmControl )
        , 1
        , 3
        , RTPortDescriptor::KindWired + RTPortDescriptor::NotificationDisabled + RTPortDescriptor::RegisterNotPermitted + RTPortDescriptor::VisibilityPublic
    }
    , {
        "external"
        , nullptr
        , &External::Base::rt_class
        , RTOffsetOf( MyTCPServer_Actor, external )
        , 1
        , 1
        , RTPortDescriptor::KindSpecial + RTPortDescriptor::NotificationDisabled + RTPortDescriptor::RegisterNotPermitted + RTPortDescriptor::VisibilityPublic
    }
};

int MyTCPServer_Actor::_followInV( RTBindingEnd & rtg_end, int rtg_portId, int rtg_repIndex )
{
    switch( rtg_portId )
    {
    case 0:
        if( rtg_repIndex < 1 )
        {
            rtg_end.port = &control;
            rtg_end.index = rtg_repIndex;
            return 1;
        }
        break;
    case 1:
        if( rtg_repIndex < 1 )
        {
            rtg_end.port = &alarmControl;
            rtg_end.index = rtg_repIndex;
            return 1;
        }
        break;
    default:
        break;
    }
    return TCPServer_Actor::_followInV( rtg_end, rtg_portId, rtg_repIndex );
}

#undef SUPER
static const RTRelayDescriptor rtg_relays[] =
{
    {
        "control"
        , &TCPServerControl::Base::rt_class
        , 1
    }
    , {
        "alarmControl"
        , &AlarmControl::Conjugate::rt_class
        , 1
    }
};

static RTActor * new_MyTCPServer_Actor( RTController * rtg_rts, RTActorRef * rtg_ref )
{
    return new MyTCPServer_Actor( rtg_rts, rtg_ref );
}

const RTActorClass MyTCPServer =
{
    &TCPServer
    , "MyTCPServer"
    , 0 /*RTVersionId*/
    , 2
    , rtg_relays
    , new_MyTCPServer_Actor
};

