var express = require('express');
var router = express.Router();

/* entry */
router.get('/', function(req, res, next) {
  res.render('index', { title: 'Stoplight Demo', color: '', error: 0 });
});

/* red no error*/
router.get('/red', function(req, res, next) {
  res.render('index', { title: 'Stoplight Demo', color: 'red', error: 0  });
});

/* yellow no error*/
router.get('/yellow', function(req, res, next) {
  res.render('index', { title: 'Stoplight Demo', color: 'yellow', error: 0  });
});

/* green no error*/
router.get('/green', function(req, res, next) {
  res.render('index', { title: 'Stoplight Demo', color: 'green', error: 0  });
});

/* red error*/
router.get('/redError', function(req, res, next) {
  res.render('index', { title: 'Stoplight Demo', color: 'red', error: 1  });
});

/* yellow error*/
router.get('/yellowError', function(req, res, next) {
  res.render('index', { title: 'Stoplight Demo', color: 'yellow', error: 1  });
});

/* green error*/
router.get('/greenError', function(req, res, next) {
  res.render('index', { title: 'Stoplight Demo', color: 'green', error: 1  });
});

module.exports = router;
